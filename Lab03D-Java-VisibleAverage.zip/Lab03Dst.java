// Lab03Dst.java
// The Visible Average Program
// This is the student, starting version, of Lab 03C.


public class Lab03Dst
{
	public static void main(String args[])
	{
		System.out.println("Lab 03D");
		System.out.println();
		int num1 = 11;
		int num2 = 22;
		int num3 = 33;
		int num4 = 44;
		int num5 = 55;





		System.out.println();
	}
}
